var typed = new Typed('#element', {
      strings: ['Frontend Developer', ' &amp; a Web Developer.'],
      typeSpeed: 100,
      backspeed: 100,
      backDelay:1000,
      loop: true
});
