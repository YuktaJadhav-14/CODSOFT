let displayValue = '';

document.querySelectorAll('.button').forEach(button => {
  button.addEventListener('click', () => {
    const value = button.textContent;

    switch (value) {
      case 'AC':
        displayValue = '';
        break;
      case '<--':
        displayValue = displayValue.slice(0, -1);
        break;
      case '=':
        try {
          displayValue = eval(displayValue);
        } catch (e) {
          displayValue = 'Error';
        }
        break;
      case 'x²':
        displayValue = Math.pow(displayValue, 2);
        break;
      default:
        displayValue += value;
    }

    document.getElementById('display').value = displayValue;
  });
})

